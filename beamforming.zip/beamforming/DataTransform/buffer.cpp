#include<iostream>

using namespace std;

int main(){
    int n[5];

     for (int i = 0; i < 5; ++i) {
        cin >> n[i];
        cout << n[i] << endl;
    }
    
    return 0;
    
}